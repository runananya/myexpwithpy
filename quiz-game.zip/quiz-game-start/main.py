from question_model import Question 
from data import question_data
from quiz_brain import QuizBrain
question_bank=[]
name=input("hey name pls")
for question in question_data:
    q_text=question["text"]
    q_ans=question["answer"]
    newq=Question(q_text,q_ans)
    
    question_bank.append(newq)
    

quiz=QuizBrain(question_bank)
while quiz.still_qs:
    quiz.next_question()
print("Thanks for participating!")