class QuizBrain:
    def __init__(self,list):
        self.numbers=0
        self.list=list
        self.q_num=0
        self.score=0
    def next_question(self):
        curr=self.list[self.q_num]
        self.q_num+=1
        userans=input(f"Q{self.q_num}:{curr.text}(True/False):")
        self.check_ans(userans,curr.ans)
    def still_qs(self):
        if self.q_num<len(self.list)-1:
            return True
        else:
            return False
    def check_ans(self,userans,correct):
        if userans.lower()==correct.lower():
            print("That's right!")
            self.score+=1
        else:
            print("Uh Oh! That's wrong")
            self.score-=1
        print(f"Your score is : {self.score}")    
        
        